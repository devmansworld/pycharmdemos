import time
import unittest
import os
from selenium import webdriver
from bs4 import BeautifulSoup
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

from selenium import webdriver

# Set the directory containing the Microsoft Edge WebDriver executable
webdriver_dir = os.path.expanduser("~")  # Use the user's home directory

# Add the WebDriver directory to the PATH environment variable
os.environ["PATH"] += os.pathsep + webdriver_dir

# Initialize the Edge WebDriver (without specifying executable_path)
driver = webdriver.Edge()

# Set the directory containing the Microsoft Edge WebDriver executable
webdriver_dir = os.path.expanduser("~")  # Use the user's home directory

# Add the WebDriver directory to the PATH environment variable
os.environ["PATH"] += os.pathsep + webdriver_dir

class MySeleniumTest(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        # This method will be executed once before all the tests in the class.
        cls.driver = webdriver.Edge()  # No need to specify executable_path here

    @classmethod
    def tearDownClass(cls):
        # This method will be executed once after all the tests in the class.
        cls.driver.quit()

    def setUp(self):
        # This method will be executed before each test.
        pass

    def tearDown(self):
        # This method will be executed after each test.
        pass

    def test_google_search(self):
        self.driver.get("https://www.google.com")
        self.assertIn("Google", self.driver.title)

    def test_open_example_website(self):
        self.driver.get("https://example.com")
        self.assertIn("Example Domain", self.driver.title)

if __name__ == "__main__":
    unittest.main()
