import unittest
import os
from selenium import webdriver
import HtmlTestRunner  # Import the HTMLTestRunner library

# Set the directory containing the Microsoft Edge WebDriver executable
webdriver_dir = os.path.expanduser("~")  # Use the user's home directory

# Add the WebDriver directory to the PATH environment variable
os.environ["PATH"] += os.pathsep + webdriver_dir

class MySeleniumTest(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        cls.driver = webdriver.Edge()

    @classmethod
    def tearDownClass(cls):
        cls.driver.quit()

    def setUp(self):
        pass

    def tearDown(self):
        pass

    def test_google_search(self):
        self.driver.get("https://www.google.com")
        self.assertIn("Google", self.driver.title)

    def test_open_example_website(self):
        self.driver.get("https://example.com")
        self.assertIn("Example Domain", self.driver.title)

if __name__ == "__main__":
    unittest.main(testRunner=HtmlTestRunner.HTMLTestRunner(output='test-reports'))
