from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

def login(driver, username, password):
    try:
        username_input = driver.find_element(By.ID, 'username')  # Try locating by ID
    except:
        # If not found, try locating by visible text in the label or placeholder attribute
        username_input = driver.find_element(By.XPATH, "//input[contains(@placeholder, 'Username') or contains(@placeholder, 'username')]")

    username_input.send_keys(username)

    try:
        password_input = driver.find_element(By.ID, 'password')  # Try locating by ID
    except:
        # If not found, try locating by visible text in the label or placeholder attribute
        password_input = driver.find_element(By.XPATH, "//input[contains(@placeholder, 'Password') or contains(@placeholder, 'password')]")

    password_input.send_keys(password)
    password_input.send_keys(Keys.RETURN)

def main():
    driver = webdriver.Chrome('path_to_chromedriver')
    driver.get('https://example.com/login')

    try:
        login(driver, 'your_username', 'your_password')

        # Wait for a specific element that indicates the page has loaded.
        wait = WebDriverWait(driver, 10)
        wait.until(EC.presence_of_element_located((By.ID, 'element_id')))

        # Perform actions on the logged-in page
        # ...

        # Log out
        logout_button = driver.find_element(By.ID, 'logout_button_id')
        logout_button.click()

    except Exception as e:
        print(f"An error occurred: {str(e)}")

    finally:
        driver.quit()

if __name__ == "__main__":
    main()
