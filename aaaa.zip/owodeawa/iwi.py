import os
import sys
from selenium import webdriver
from selenium.webdriver.common.keys import Keys

# Get the user's home directory
home_directory = os.path.expanduser("~")

# Specify the name of the WebDriver executable (e.g., 'msedgedriver' for Microsoft Edge)
webdriver_name = 'msedgedriver'

# Construct the full path to the WebDriver executable
webdriver_path = os.path.join(home_directory, webdriver_name)

# Initialize the Edge WebDriver
driver = webdriver.Edge(executable_path=webdriver_path)

# Open the convenience store website
driver.get('https://www.homedepot.com.mx')

# Perform the shopping cart operations
products = ['pan', 'pen', 'apple']

for product in products:
    # Find the search input element and enter the product name
    search_box = driver.find_element_by_name('search')
    search_box.clear()
    search_box.send_keys(product)
    search_box.send_keys(Keys.RETURN)

    # Locate and click the 'Add to Cart' button
    add_to_cart_button = driver.find_element_by_css_selector('.add-to-cart-button')
    add_to_cart_button.click()

# View the cart and proceed to checkout
cart_button = driver.find_element_by_css_selector('.cart-button')
cart_button.click()

# Go to the checkout page
checkout_button = driver.find_element_by_css_selector('.checkout-button')
checkout_button.click()

# Close the browser
driver.quit()
