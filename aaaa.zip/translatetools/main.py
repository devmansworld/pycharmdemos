from flask import Flask, request, jsonify

app = Flask(__name__)

@app.route('/detect_language', methods=['POST'])
def detect_language():
    data = request.get_json()
    word = data.get('word', '')

    # Implement your language detection logic here (e.g., the function from the previous answer)
    detected_language = detect_language_function(word)

    return jsonify({'detected_language': detected_language})

if __name__ == '__main__':
    app.run(debug=True)
