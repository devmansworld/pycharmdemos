import pyautogui
import math
import time

# Set the radius of the circle and the number of steps
radius = 100
num_steps = 360  # 360 degrees for a full circle

# Calculate the step size to move in a circle
step_size = (2 * math.pi * radius) / num_steps

# Center of the circle (you can adjust these coordinates)
center_x, center_y = 500, 500

# Slow down the mouse movement by adding a delay between steps
delay_between_steps = 0.1  # Adjust as needed

# Move the mouse in a clockwise circle
for i in range(num_steps):
    angle = i * step_size
    x = center_x + radius * math.cos(angle)
    y = center_y + radius * math.sin(angle)
    pyautogui.moveTo(x, y, duration=0.1)
    time.sleep(delay_between_steps)

# Move the mouse back to the original position (optional)
pyautogui.moveTo(center_x, center_y, duration=0.1)
