from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.firefox.options import FirefoxOptions
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from bs4 import BeautifulSoup
import time

options = FirefoxOptions()
# options.binary_location = '/path/to/firefox'  # If Firefox is not in the system PATH

# Initialize the Firefox WebDriver
driver = webdriver.Firefox(options=options)

# Website URL
website_url = 'https://www.homedepot.com.mx/'  # Replace with the actual website URL

# Navigate to the website
driver.get(website_url)

# Search for items
search_query = 'shovel'
search_input = driver.find_element_by_id('SimpleSearchForm_SearchTerm')  # Replace with the actual element ID
search_input.send_keys(search_query)
search_input.send_keys(Keys.RETURN)

try:
    # Wait for the 'btn1' element to be present for a maximum of 5 seconds
    element = WebDriverWait(driver, 5).until(
        EC.presence_of_element_located((By.CLASS_NAME, 'btn1'))
    )

    # Perform actions on the element once it's found (e.g., click)
    element.click()

    # Wait for 4 seconds (you can adjust the duration)
    time.sleep(4)

    # Repeat the process for additional items (e.g., paint gallons, scissors)

    # Navigate to the cart page
    cart_link = driver.find_element_by_id('link-cart')  # Replace with the actual element ID
    cart_link.click()

    # Wait for 3 seconds (you can adjust the duration)
    time.sleep(3)

    # Parse the cart page using BeautifulSoup
    cart_page_html = driver.page_source
    soup = BeautifulSoup(cart_page_html, 'html.parser')

    # Find and extract the total value
    total_element = soup.find('span', {'class': 'summary__text-value summary__text-value--price'})  # Replace with the actual HTML structure
    cart_total = total_element.text.strip()

    # Print the cart total
    print(f"Cart Total: {cart_total}")

except Exception as e:
    # Handle any exceptions (e.g., element not found, timeout)
    print(f"An error occurred: {str(e)}")

finally:
    # Close the browser
    driver.quit()
