from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from bs4 import BeautifulSoup
from selenium.webdriver.firefox.service import Service

# Set the path to the GeckoDriver executable
geckodriver_path = '/home/nix/bin/geckodriver'  # Replace with your actual path

# Initialize the GeckoDriver service with the specified path
geckodriver_service = Service(geckodriver_path)

# Initialize Firefox WebDriver with the GeckoDriver service
driver = webdriver.Firefox(service=geckodriver_service)


# Website URL
website_url = 'https://example.com'  # Replace with the actual website URL

# Navigate to the website
driver.get(website_url)

# Search for items
search_query = 'shovel'
search_input = driver.find_element_by_id('search-input')  # Replace with the actual element ID
search_input.send_keys(search_query)
search_input.send_keys(Keys.RETURN)

# Add items to the cart
add_to_cart_button = driver.find_element_by_id('add-to-cart-button')  # Replace with the actual element ID
add_to_cart_button.click()

# Repeat the process for additional items (e.g., paint gallons, scissor)

# Navigate to the cart page
cart_link = driver.find_element_by_id('cart-link')  # Replace with the actual element ID
cart_link.click()

# Parse the cart page using BeautifulSoup
cart_page_html = driver.page_source
soup = BeautifulSoup(cart_page_html, 'html.parser')

# Find and extract the total value
total_element = soup.find('span', {'class': 'cart-total'})  # Replace with the actual HTML structure
cart_total = total_element.text.strip()

# Print the cart total
print(f"Cart Total: {cart_total}")

# Close the browser
driver.quit()
