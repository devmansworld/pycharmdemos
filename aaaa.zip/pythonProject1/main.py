class Product:
    def __init__(self, product_id, name, price, quantity):
        self.product_id = product_id
        self.name = name
        self.price = price
        self.quantity = quantity

    def __str__(self):
        return f"{self.name} (Product ID: {self.product_id})"


class Warehouse:
    def __init__(self):
        self.products = []

    def add_product(self, product):
        self.products.append(product)

    def list_products(self):
        print("Warehouse Inventory:")
        for product in self.products:
            print(f"{product}: {product.quantity} available")

    def fulfill_order(self, order):
        for ordered_product in order.products:
            for warehouse_product in self.products:
                if (
                    warehouse_product.product_id == ordered_product.product_id
                    and warehouse_product.quantity >= ordered_product.quantity
                ):
                    warehouse_product.quantity -= ordered_product.quantity
                    print(f"Fulfilled: {ordered_product}")
                    break
            else:
                print(f"Not enough stock for: {ordered_product}")

class Order:
    def __init__(self, order_id, products):
        self.order_id = order_id
        self.products = products

    def __str__(self):
        return f"Order ID: {self.order_id}"

# Create a warehouse and add products
warehouse = Warehouse()
warehouse.add_product(Product(1, "Shovel", 20.0, 50))
warehouse.add_product(Product(2, "Paint Gallon", 15.0, 100))
warehouse.add_product(Product(3, "Scissors", 5.0, 200))

# List the products in the warehouse
warehouse.list_products()

# Create customer orders
order1 = Order(101, [Product(1, "Shovel", 20.0, 2), Product(3, "Scissors", 5.0, 5)])
order2 = Order(102, [Product(2, "Paint Gallon", 15.0, 10), Product(1, "Shovel", 20.0, 3)])

# Fulfill customer orders
print("\nFulfilling Orders:")
warehouse.fulfill_order(order1)
warehouse.fulfill_order(order2)

# List the remaining products in the warehouse after orders are fulfilled
warehouse.list_products()
