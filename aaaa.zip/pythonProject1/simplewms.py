from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import letter

class Product:
    def __init__(self, product_id, name, price, quantity):
        self.product_id = product_id
        self.name = name
        self.price = price
        self.quantity = quantity

    def __str__(self):
        return f"{self.name} (Product ID: {self.product_id}) - Price: ${self.price:.2f} - Quantity: {self.quantity}"

class Warehouse:
    def __init__(self):
        self.products = []

    def add_product(self, product):
        self.products.append(product)

    def list_products(self):
        print("Warehouse Inventory:")
        for product in self.products:
            print(product)

    def find_product_by_id(self, product_id):
        for product in self.products:
            if product.product_id == product_id:
                return product
        return None

    def update_product_quantity(self, product_id, new_quantity):
        product = self.find_product_by_id(product_id)
        if product:
            product.quantity = new_quantity
            if new_quantity <= 3:
                print(f"Alert: Low stock for {product}. Quantity: {new_quantity}")

class ShoppingCart:
    def __init__(self):
        self.items = []

    def add_item(self, product, quantity):
        if product.quantity >= quantity:
            self.items.append({"product": product, "quantity": quantity})
            product.quantity -= quantity
        else:
            print(f"Alert: Not enough stock for {product}. Available Quantity: {product.quantity}")

    def list_items(self):
        print("Shopping Cart:")
        for item in self.items:
            product = item["product"]
            quantity = item["quantity"]
            print(f"{product} - Quantity: {quantity}")

    def calculate_total(self):
        total = 0
        for item in self.items:
            product = item["product"]
            quantity = item["quantity"]
            total += product.price * quantity
        return total

    def generate_bill(self):
        filename = "bill.pdf"

        c = canvas.Canvas(filename, pagesize=letter)
        c.setFont("Helvetica", 12)

        c.drawString(100, 750, "Billing Information")
        c.line(100, 747, 500, 747)

        y = 720
        total_price = 0

        for item in self.items:
            product = item["product"]
            quantity = item["quantity"]
            price = product.price * quantity
            total_price += price

            c.drawString(100, y, f"Product: {product.name}")
            c.drawString(250, y, f"Quantity: {quantity}")
            c.drawString(350, y, f"Price: ${product.price:.2f}")
            c.drawString(450, y, f"Total: ${price:.2f}")

            y -= 20

        c.line(100, y, 500, y)
        y -= 20
        c.drawString(350, y, "Total Price:")
        c.drawString(450, y, f"${total_price:.2f}")

        c.save()

        print("Billing Information has been generated and saved as 'bill.pdf'")

# Create a warehouse and add products
warehouse = Warehouse()
warehouse.add_product(Product(1, "Shovel", 20.0, 10))
warehouse.add_product(Product(2, "Paint Gallon", 15.0, 5))
warehouse.add_product(Product(3, "Scissors", 5.0, 2))
warehouse.add_product(Product(4, "Hammer", 10.0, 3))
warehouse.add_product(Product(5, "Screwdriver", 8.0, 1))
warehouse.add_product(Product(6, "Wrench", 12.0, 4))

# Create a shopping cart
cart = ShoppingCart()

# Add products to the shopping cart and update quantities
cart.add_item(warehouse.find_product_by_id(1), 5)
cart.add_item(warehouse.find_product_by_id(3), 4)
cart.add_item(warehouse.find_product_by_id(5), 3)

# List items in the shopping cart
cart.list_items()

# Calculate the total price of items in the cart
total_price = cart.calculate_total()
print(f"Total Price: ${total_price:.2f}")

# Generate and save the bill as a PDF
cart.generate_bill()
