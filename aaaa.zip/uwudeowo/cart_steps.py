# home_cart_steps.py
from behave import *

@given('Dado que estoy en la página principal de la tienda en línea')
def step_given_open_homepage(context):
    # Add code to open the online store's homepage (similar to driver.get('https://www.homedepot.com.mx'))

# Define other step definitions...
