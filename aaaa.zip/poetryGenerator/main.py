from selenium import webdriver
from selenium.webdriver.common.keys import Keys
import time

# Initialize the WebDriver (specify the path to your WebDriver executable)
driver = webdriver.Chrome()

# Open eBay's search page for Fender guitars
driver.get("https://www.ebay.com/")
search_box = driver.find_element_by_name("_nkw")
search_box.send_keys("Fender guitars")
search_box.send_keys(Keys.RETURN)

# Wait for the search results to load (you may need to adjust the sleep time)
time.sleep(5)

# Click the first search result (assuming it's a product listing)
first_result = driver.find_element_by_css_selector(".s-item")
first_result.click()

# Wait for the product page to load (adjust the sleep time if needed)
time.sleep(3)

# Extract information from the product page (e.g., title and price)
product_title = driver.find_element_by_css_selector("h1 span").text
product_price = driver.find_element_by_css_selector(".x-price-primary").text

# Print the extracted information
print("Product Title:", product_title)
print("Product Price:", product_price)

# Optionally, you can save the information to a file or database
# For example, you could write it to a text file:
with open("product_info.txt", "w") as file:
    file.write("Product Title: " + product_title + "\n")
    file.write("Product Price: " + product_price + "\n")

# Close the browser
driver.quit()
